#!/bin/sh


rm -rf /koolshare/thunder
rm -rf /init.d/S02Thunder.sh
rm -rf /koolshare/scripts/thunder_*.sh
rm -rf /webs/Module_thunder.asp


